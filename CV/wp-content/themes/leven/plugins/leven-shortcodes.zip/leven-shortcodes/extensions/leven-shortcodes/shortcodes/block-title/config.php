<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Block Title', 'leven-shortcodes' ),
		'description' => esc_html__( 'Block title', 'leven-shortcodes' ),
		'tab'         => esc_html__( 'Leven Elements', 'leven-shortcodes' ),
        'title_template' => '{{- title }}: {{- o.title }}',
	)
);